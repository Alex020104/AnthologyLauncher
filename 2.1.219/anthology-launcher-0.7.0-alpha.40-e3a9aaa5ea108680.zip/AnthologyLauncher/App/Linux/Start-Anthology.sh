#!/usr/bin/env bash
set -euo pipefail
umask 077
launcher_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 ]]; then
    printf '%s\n' 'This desktop build requires Linux x86_64. Do not run the launcher through Proton.' >&2
    exit 1
fi
export ANTHOLOGY_DATA_ROOT="${ANTHOLOGY_DATA_ROOT:-${XDG_DATA_HOME:-$HOME/.local/share}/AnthologyLauncherLinux}"
mkdir -p -- "$ANTHOLOGY_DATA_ROOT/Logs"
chmod 700 -- "$ANTHOLOGY_DATA_ROOT"
cd -- "$launcher_dir/App"
system_report() {
    printf '%s\n' 'A.N.T.H.O.L.O.G.Y / Linux desktop diagnostics'
    if [[ -r /etc/os-release ]]; then
        awk -F= '$1 == "PRETTY_NAME" { print "Distribution: " substr($0, index($0, "=") + 1) }' /etc/os-release
    fi
    printf 'Kernel / architecture: '; uname -srmo
    getconf GNU_LIBC_VERSION 2>/dev/null || true
    printf 'Session: %s\n' "${XDG_SESSION_TYPE:-unknown}"
    printf '%s\n' 'Native library requires GTK3, WebKitGTK 4.1, libnotify, GLIBC 2.38+, GLIBCXX 3.4.31+.'
    if command -v bsdtar >/dev/null 2>&1; then bsdtar --version; else printf '%s\n' 'bsdtar is missing (needed for mod archives).'; fi
    if ! command -v xdg-open >/dev/null 2>&1; then printf '%s\n' 'xdg-open is missing (needed for external links).'; fi
}
native_status=0
native_check='ldd is unavailable; native dependencies have not been checked.'
if command -v ldd >/dev/null 2>&1; then
    native_check="$(LC_ALL=C ldd ./Photino.Native.so 2>&1)" || native_status=$?
fi
if [[ " ${*} " == *" --diagnose "* ]]; then
    { system_report; printf '%s\n' "$native_check"; } | tee "$ANTHOLOGY_DATA_ROOT/Logs/linux-dependencies.log"
    # Do not start the launcher, Proton or the game, or install any packages.
    exit "$native_status"
fi
if [[ ! -x ./AnthologyLauncher.Linux ]]; then
    if [[ "${ANTHOLOGY_LINUX_BOOTSTRAPPED:-}" == 1 ]]; then chmod u+x ./AnthologyLauncher.Linux; fi
fi
if [[ ! -x ./AnthologyLauncher.Linux ]]; then
    printf '%s\n' 'Run: chmod +x App/AnthologyLauncher.Linux (from the extracted package folder)' >&2
    exit 1
fi
if [[ " ${*} " != *" --headless "* ]]; then
    if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
        printf '%s\n' 'No graphical Linux session. Run the launcher on your desktop, not a text console.' >&2
        exit 1
    fi
    if [[ "$native_status" -ne 0 || "$native_check" == *"not found"* ]]; then
        { system_report; printf '%s\n' "$native_check"; } | tee "$ANTHOLOGY_DATA_ROOT/Logs/linux-host.log" >&2
        printf '%s\n' 'Missing/incompatible desktop libraries. Send the diagnostic output to the developer.' >&2
        exit 1
    fi
fi
printf '%s\n' 'Starting Anthology desktop window. Close the window to exit.'
# One bounded run log. Diagnostic --headless mode prints a PRIVATE session URL.
# pipefail preserves host failures, including a missing native runtime dependency.
set +e
./AnthologyLauncher.Linux "$@" 2>&1 | awk '
    { print; fflush(); if (bytes < 1048576) { print > log; bytes += length($0) + 1; fflush(log) } }
' log="$ANTHOLOGY_DATA_ROOT/Logs/linux-host.log"
launcher_result=${PIPESTATUS[0]}
if [[ $launcher_result -ne 0 && $launcher_result -ne 42 ]]; then
    printf 'Launcher exited with code %s. Log: %s\n' "$launcher_result" "$ANTHOLOGY_DATA_ROOT/Logs/linux-host.log" >&2
fi
exit "$launcher_result"
