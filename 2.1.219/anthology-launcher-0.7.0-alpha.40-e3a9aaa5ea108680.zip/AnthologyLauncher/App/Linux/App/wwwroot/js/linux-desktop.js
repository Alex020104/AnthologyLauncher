(() => {
    "use strict";
    let owner;
    window.anthologyLinuxLinks = { bind: reference => { owner = reference; } };
    // Only HTTP(S) links are passed to the authenticated Blazor component, never
    // arbitrary native commands. Keep remote sites out of the launcher's WebView.
    function openExternal(event) {
        if (!owner || event.defaultPrevented || !event.isTrusted
            || (event.type === "click" && event.button !== 0)
            || (event.type === "auxclick" && event.button !== 1)) return;
        const link = event.composedPath().find(node => node instanceof HTMLAnchorElement);
        if (!link || !link.hasAttribute("href")) return;
        let url;
        try { url = new URL(link.href, document.baseURI); } catch { return; }
        if (!["http:", "https:"].includes(url.protocol) || url.origin === location.origin) return;
        event.preventDefault();
        owner.invokeMethodAsync("OpenExternalLink", url.href).catch(() => {});
    }
    // The shared capture-phase listener has already suppressed duplicate clicks.
    document.addEventListener("click", openExternal);
    document.addEventListener("auxclick", openExternal);
})();
