(() => {
    const times = new WeakMap();
    window.addEventListener('message', e => {
        if (e.origin !== 'https://www.youtube.com') return;
        try {
            const message = typeof e.data === 'string' ? JSON.parse(e.data) : e.data;
            if (typeof message?.info?.currentTime === 'number') times.set(e.source, message.info.currentTime);
        } catch { }
    });
    document.addEventListener('load', e => {
        if (!(e.target instanceof HTMLIFrameElement) || !e.target.src.startsWith('https://www.youtube.com/embed/')) return;
        e.target.contentWindow?.postMessage(JSON.stringify({ event: 'listening', id: 'anthology' }), 'https://www.youtube.com');
    }, true);
    window.anthologyPauseForPopout = element => {
        const video = element?.querySelector('video');
        if (video) { video.pause(); return video.currentTime || 0; }
        const frame = element?.querySelector('iframe');
        if (frame?.src.startsWith('https://www.youtube.com/embed/')) {
            frame.contentWindow.postMessage(JSON.stringify({ event: 'command', func: 'pauseVideo', args: [] }), 'https://www.youtube.com');
            return times.get(frame.contentWindow) || 0;
        }
        return 0;
    };
})();
