(() => {
    "use strict";
    // Loaded before Blazor. Do not launch a browser here: the framework owns
    // target=_blank. This listener only cancels repeat user activations.
    if (window.anthologyExternalLinksBound) return;
    window.anthologyExternalLinksBound = true;
    const recent = new Map();
    const interval = 1000;
    function guard(event) {
        if (event.defaultPrevented || (event.type === "click" && event.button !== 0)
            || (event.type === "auxclick" && event.button !== 1)) return;
        const link = event.composedPath().find(node => node instanceof HTMLAnchorElement);
        if (!link || !link.hasAttribute("href")) return;
        let url;
        try { url = new URL(link.href, document.baseURI); } catch { return; }
        if (!["http:", "https:"].includes(url.protocol) || url.origin === location.origin) return;
        const now = performance.now();
        for (const [key, time] of recent) if (now - time >= interval) recent.delete(key);
        if (event.detail > 1 || recent.has(url.href)) {
            event.preventDefault();
            event.stopImmediatePropagation();
            return;
        }
        if (recent.size >= 64) recent.delete(recent.keys().next().value);
        recent.set(url.href, now);
    }
    document.addEventListener("click", guard, true);
    document.addEventListener("auxclick", guard, true);
})();
