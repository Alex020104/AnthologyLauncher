A.N.T.H.O.L.O.G.Y — Windows / Linux integrated launcher
13 October 2026 / shared launcher code alpha.40 / native Linux + PortProton

Кратко по-русски
Это Linux-сборка того же лаунчера, с обычным окном, а не вкладкой браузера.
Общий ZIP обновления распаковывается в корень существующей игры, с сохранением
структуры каталогов. Windows запускается через AnomalyLauncher.exe.
Linux запускается из корня игры:
  bash AnomalyLauncher.sh
Он открывает нативное окно и перезапускает его после штатного обновления.
Если получен отдельный диагностический Linux-пакет, в папке пакета:
  chmod +x Start-Anthology.sh App/AnthologyLauncher.Linux
  ./Start-Anthology.sh
Не запускайте сам Linux-лаунчер через Proton. Proton нужен игре и MO2.
Для человека, приславшего PortProton.log (CachyOS):
  - среда запуска: PortProton;
  - папка: /home/xuser/PortProton (проверьте своё имя пользователя);
  - префикс: DEFAULT;
  - Wine: GE-PROTON10-15; графика: режим 6, как в присланном логе;
  - игра: существующая папка с fsgame.ltx внутри DEFAULT/drive_c/Games;
  - MO2: существующая папка с ModOrganizer.exe, затем выбор профиля в лаунчере.
Папки и версии выбираются из уже установленного PortProton. Сборка не создаёт
новый префикс, не переносит игру в Steam и не заменяет файлы .ppdb игры/MO2.
Для передачи аргументов используется небольшой Win32-помощник без .NET и
WebView2. Он запускается через PortProton; сам интерфейс остаётся нативным.
Временная папка помощника удаляется после завершения. Если лаунчер закрыли
раньше игры, завершённые задания очищаются при следующем запуске лаунчера.
Если окно не появилось или название Linux неизвестно, выполните:
  bash Start-Anthology.sh --diagnose
Пришлите вывод: он покажет систему и отсутствующие библиотеки. Эта проверка
не запускает игру, не переустанавливает систему и не меняет префикс Proton.
На реальном Linux пакет ещё не проверен; это кандидат для тестирования,
а не подтверждение полной совместимости. Старые дистрибутивы могут потребовать
другую сборку нативной библиотеки. Windows и Linux хранятся раздельно внутри
одной папки AnthologyLauncher и доставляются одним подписанным выпуском.

This is the Linux build of the SAME launcher interface and shared game/update
logic. It uses a native desktop window, NOT a browser tab. The Windows build
keeps its existing WPF/WebView2 shell. Do not run this Linux package through
Proton: only the game and MO2 use Proton. Both runtimes share the signed channel.

Quick start
1. Extract the unified update ZIP into the EXISTING game folder. Preserve paths.
2. Open a terminal in the game folder: bash AnomalyLauncher.sh
   The Windows launcher still uses AnomalyLauncher.exe. For a standalone
   diagnostic Linux package, use bash Start-Anthology.sh instead.
3. A normal Anthology desktop window opens. The .NET runtime is included.
   The UI uses a private authenticated localhost connection inside its native
   WebView. It is not a public website and requires no online interface server.
4. At first launch, or in Paths and installation / Пути и установка, choose:
   PortProton (regular installation):
   - PortProton root containing data/scripts/start.sh;
   - EXISTING prefix (e.g. DEFAULT) and installed Wine engine from the lists;
   - graphics mode matching the working PortProton configuration.
   OR Steam Proton:
   - proton: the executable script in your installed Proton directory;
   - compatdata: the EXISTING game prefix parent, containing pfx/drive_c;
   - Steam root: the installed Steam folder.
   For either runtime:
   - game root: the folder with fsgame.ltx and bin;
   - MO2 root: the folder containing ModOrganizer.exe.
   Choose the SAME Proton and prefix in which the game and MO2 already work.
   A new prefix is NOT created automatically. Its Z: mapping must point to /.
5. Save, then choose your MO2 profile in the launcher. Both detailed and compact
   layouts use the existing interface. Close the native window to exit; closing
   is blocked while a protected file operation is active. File pickers are
   native desktop dialogs. Social/content links open your usual browser.
   You can open the interface before configuring Proton, but game launch will
   require a valid existing prefix. No game/MO2 files change during first setup.

Requirements and limitations
- Linux x86_64 desktop with GTK3, WebKitGTK 4.1 and libnotify. The bundled
  Photino.Native 4.0.22 binary requires GLIBC_2.38 and GLIBCXX_3.4.31. This is
  NOT a universal binary for older Linux distributions: Ubuntu 22.04/Debian 12
  cannot run this exact native library without a compatible rebuild.
- The distribution must also satisfy .NET 10 native dependencies (ICU,
  OpenSSL, libstdc++, zlib). The startup script checks missing desktop shared
  libraries with ldd and prints their names instead of failing silently.
  Dependency installation varies by distribution; no system packages,
  environment-wide Wine settings or Steam prefixes are changed automatically.
- Installed Steam/Proton OR PortProton and an already prepared game/MO2 prefix. Launching
  Proton outside Steam, Flatpak permissions and MO2 compatibility depend on
  the player's setup; this candidate has NOT been run on a Linux machine yet.
- PortProton mode supports direct EXE launch (game and MO2), NOT BAT/CMD/MSI
  entrypoints or Flatpak installations. Use the existing Steam mode for an
  already working Steam setup. Neither mode installs Wine or system packages.
  PortProton itself may do its normal runtime/prefix maintenance when launching.
  Per-game .ppdb tweaks are not imported: choose the engine/prefix/graphics in
  the setup panel. Existing global PortProton configuration remains its own.
- Install bsdtar (libarchive-tools) for 7z/FOMOD/BAIN archives. File pickers do
  not require zenity/kdialog in the normal desktop mode.
- Games with filenames differing only in letter case require testing on the
  target filesystem. Existing MO2 Portable paths are rewritten for the chosen
  game at launch; do not run Windows MO2 and this launcher simultaneously.
- Game and launcher updates use the existing signed channel. A unified launcher
  package includes the Linux runtime directly and a deferred Windows payload.
  Legacy Windows-only launcher packages are excluded on Linux. Signatures and
  hashes are checked normally. Atomic file replacement preserves running Linux
  mappings; AnomalyLauncher.sh restarts the native process after the UI closes.
- Windows AI Helper is not started. A separately configured AI service may be
  used. Community API features need the configured server; no local Community
  API server is bundled. Video popout opens an external browser page.
- The Linux/Proton setup panel currently uses Russian labels. The shared
  launcher interface retains its existing language switcher.

Personal settings and diagnostics
${XDG_DATA_HOME:-~/.local/share}/AnthologyLauncherLinux/
  linux-runtime.json             selected Proton/prefix paths
  Logs/linux-host.log            startup/interface/Proton output
  Logs/last-proton-launch.log    last launch path, process ID or startup error
  Logs/last-portproton-launch.log  PortProton and bridge exit status
  Logs/linux-dependencies.log  system/library report from --diagnose
ANTHOLOGY_DATA_ROOT overrides this location. Existing Windows launcher data
and identity are not imported automatically. Do not publish personal logs or
settings without reviewing/removing private data. The explicit diagnostic
--headless mode prints a PRIVATE session URL; normal desktop startup does not.

Validation performed on Windows: native-host compilation, Linux-target
cross-publication, unit tests and HTTP resource/authentication checks; native
Win32 bridge round-trip test with Unicode/profile/save arguments, working
directory, quotes, empty arguments, exit code and malformed-request handling.
Still required on actual Linux: desktop interaction, MO2 VFS injection, game
and save launch, real archive installation, updates/rollback and chat.

PortProton CLI reference used for integration:
https://github.com/Castro-Fidel/PortWINE/blob/master/data_from_portwine/scripts/start.sh
https://github.com/Castro-Fidel/PortWINE/blob/master/data_from_portwine/scripts/functions_helper
