#!/usr/bin/env bash
set -uo pipefail
game_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
linux_start="$game_root/AnthologyLauncher/App/Linux/Start-Anthology.sh"
if [[ ! -f "$linux_start" || ! -f "$game_root/fsgame.ltx" ]]; then
    printf '%s\n' 'Incomplete Anthology installation. Extract the complete launcher update into the game folder.' >&2
    exit 1
fi
export ANTHOLOGY_GAME_ROOT="$game_root"
export ANTHOLOGY_LAUNCHER_ROOT="$game_root/AnthologyLauncher"
export ANTHOLOGY_LINUX_BOOTSTRAPPED=1
# New runtime files are installed atomically while Linux keeps the old mapped
# executable alive. Start a NEW process after the old window has fully closed.
for ((restart=0; restart<4; restart++)); do
    bash "$linux_start" "$@"
    result=$?
    [[ $result -eq 42 ]] || exit "$result"
    set --
done
printf '%s\n' 'Repeated launcher restart detected. See Logs/linux-host.log.' >&2
exit 1
